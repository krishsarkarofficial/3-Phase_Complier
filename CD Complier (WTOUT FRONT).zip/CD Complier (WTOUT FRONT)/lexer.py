import re

# Token specifications
TOKEN_SPECIFICATION = [
    ("COMMENT",  r'//.*'),              # To skip single-line comments
    ("NUMBER",   r'\d+(\.\d*)?'),      # For integers or floats
    ("ID",       r'[A-Za-z_]\w*'),       # For identifiers
    ("OP",       r'==|!=|<=|>=|[+\-*/=<>]'), # For operators (longest match first)
    ("DELIM",    r'[(){};]'),           # For delimiters
    ("NEWLINE",  r'\n'),                 # Line endings
    ("SKIP",     r'[ \t]+'),             # To skip whitespace
    ("MISMATCH", r'.'),                  # Any other character (error)
]

KEYWORDS = {"if", "else", "int", "float", "while", "for", "return"}

# Compile the regex for tokenization
token_regex = re.compile("|".join(
    f"(?P<{name}>{pattern})" for name, pattern in TOKEN_SPECIFICATION
))

class Token:
    """A simple class to hold token information."""
    def __init__(self, type, value, line):
        self.type = type
        self.value = value
        self.line = line

    def __repr__(self):
        return f"Token({self.type}, '{self.value}', L{self.line})"

def tokenize(code):
    """
    Generates tokens from the source code.
    """
    tokens = []
    line_num = 1
    errors = []

    for mo in token_regex.finditer(code):
        kind = mo.lastgroup
        value = mo.group()

        if kind == "NEWLINE":
            line_num += 1
        elif kind == "SKIP" or kind == "COMMENT":
            continue
        elif kind == "MISMATCH":
            errors.append(f"Lexical Error: Unexpected character '{value}' on line {line_num}")
        else:
            # Check if the identifier is a keyword
            if kind == "ID" and value in KEYWORDS:
                kind = "KEYWORD"
            tokens.append(Token(kind, value, line_num))

    # Add an End-Of-File token for the parser
    tokens.append(Token("EOF", "", line_num))
    return tokens, errors
