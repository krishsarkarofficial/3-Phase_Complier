# Abstract Syntax Tree (AST) Node definitions
class AST: pass

class BinOp(AST):
    def __init__(self, left, op, right):
        self.left = left
        self.op = op
        self.right = right

class Number(AST):
    def __init__(self, token):
        self.token = token
        self.value = token.value

class Variable(AST):
    def __init__(self, token):
        self.token = token
        self.value = token.value

class Assign(AST):
    def __init__(self, left, op, right):
        self.left = left
        self.op = op
        self.right = right

class VarDecl(AST):
    def __init__(self, type_node, var_node, assign_node=None):
        self.type_node = type_node
        self.var_node = var_node
        self.assign_node = assign_node

class Type(AST):
    def __init__(self, token):
        self.token = token
        self.value = token.value

class If(AST):
    def __init__(self, condition, if_block, else_block=None):
        self.condition = condition
        self.if_block = if_block
        self.else_block = else_block

class Block(AST):
    def __init__(self):
        self.statements = []

class Program(AST):
    def __init__(self):
        self.children = []

# Parser implementation
class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.current_token = self.tokens[self.pos]
        self.errors = []

    def error(self, message):
        err_msg = f"Syntax Error: {message} at line {self.current_token.line}. Encountered {self.current_token.type}('{self.current_token.value}')."
        self.errors.append(err_msg)
        # Simple error recovery: advance until a potential statement boundary
        while self.current_token.type != 'EOF' and self.current_token.value not in [';', '}']:
             self.advance()

    def advance(self):
        self.pos += 1
        if self.pos < len(self.tokens):
            self.current_token = self.tokens[self.pos]
        else:
            self.current_token = self.tokens[-1] # Stay at EOF

    def eat(self, token_type, token_value=None):
        if self.current_token.type == token_type and \
           (token_value is None or self.current_token.value == token_value):
            self.advance()
        else:
            expected = f"'{token_value}'" if token_value else token_type
            self.error(f"Expected {expected}")

    def program(self):
        """program : (declaration | statement)*"""
        node = Program()
        while self.current_token.type != "EOF":
            if self.current_token.value in ['int', 'float']:
                node.children.extend(self.declaration())
            else:
                node.children.append(self.statement())
        return node

    def declaration(self):
        """declaration : type_specifier ID ('=' expression)? (',' ID ('=' expression)?)* ';'"""
        declarations = []
        type_node = self.type_specifier()
        while self.current_token.type == 'ID':
            var_node = self.variable()
            assign_node = None
            if self.current_token.value == '=':
                op = self.current_token
                self.eat('OP', '=')
                expr_node = self.expression()
                assign_node = Assign(var_node, op, expr_node)
            declarations.append(VarDecl(type_node, var_node, assign_node))
            if self.current_token.value == ',':
                 self.eat('DELIM', ',')
                 continue
            break
        self.eat('DELIM', ';')
        return declarations

    def type_specifier(self):
        """type_specifier : 'int' | 'float'"""
        token = self.current_token
        if token.value in ('int', 'float'):
            self.eat('KEYWORD', token.value)
            return Type(token)
        self.error("Expected a type specifier (e.g., int, float)")

    def statement(self):
        """statement : if_statement | block | expression_statement"""
        if self.current_token.value == 'if':
            return self.if_statement()
        elif self.current_token.value == '{':
            return self.block()
        else:
            # Expression statement (e.g., an assignment)
            node = self.expression()
            self.eat('DELIM', ';')
            return node

    def if_statement(self):
        """if_statement : 'if' '(' expression ')' statement ('else' statement)?"""
        self.eat('KEYWORD', 'if')
        self.eat('DELIM', '(')
        condition = self.expression()
        self.eat('DELIM', ')')
        if_block = self.statement()
        else_block = None
        if self.current_token.value == 'else':
            self.eat('KEYWORD', 'else')
            else_block = self.statement()
        return If(condition, if_block, else_block)

    def block(self):
        """block : '{' statement* '}'"""
        self.eat('DELIM', '{')
        node = Block()
        while self.current_token.value != '}' and self.current_token.type != 'EOF':
             node.statements.append(self.statement())
        if self.current_token.value == '}':
            self.eat('DELIM', '}')
        else:
            self.error("Expected '}' to close block")
        return node

    def expression(self):
        """expression : assignment"""
        # Check for assignment: ID = ...
        if self.current_token.type == 'ID' and self.tokens[self.pos + 1].value == '=':
             var_node = self.variable()
             op = self.current_token
             self.eat('OP', '=')
             expr = self.expression()
             return Assign(var_node, op, expr)
        return self.comparison()

    def comparison(self):
        """comparison : term (('>' | '<' | '==' | '!=' | '>=' | '<=') term)*"""
        node = self.term()
        while self.current_token.value in ('>', '<', '==', '!=', '>=', '<='):
            op = self.current_token
            self.eat('OP', op.value)
            node = BinOp(left=node, op=op, right=self.term())
        return node

    def term(self):
        """term : factor (('+' | '-') factor)*"""
        node = self.factor()
        while self.current_token.value in ('+', '-'):
            op = self.current_token
            self.eat('OP', op.value)
            node = BinOp(left=node, op=op, right=self.factor())
        return node

    def factor(self):
        """factor : primary (('*' | '/') primary)*"""
        node = self.primary()
        while self.current_token.value in ('*', '/'):
            op = self.current_token
            self.eat('OP', op.value)
            node = BinOp(left=node, op=op, right=self.primary())
        return node

    def primary(self):
        """primary : NUMBER | ID | '(' expression ')'"""
        token = self.current_token
        if token.type == 'NUMBER':
            self.eat('NUMBER')
            return Number(token)
        elif token.type == 'ID':
            return self.variable()
        elif token.value == '(':
            self.eat('DELIM', '(')
            node = self.expression()
            self.eat('DELIM', ')')
            return node
        else:
            self.error("Invalid syntax in expression")
            return Number(Token('NUMBER', '0', token.line)) # Return dummy node

    def variable(self):
        """variable : ID"""
        node = Variable(self.current_token)
        self.eat('ID')
        return node

    def parse(self):
        ast = self.program()
        if self.current_token.type != 'EOF' and not self.errors:
             self.error("Unexpected tokens at end of file")
        return ast, self.errors
