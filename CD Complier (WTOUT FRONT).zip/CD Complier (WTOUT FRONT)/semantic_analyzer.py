class Symbol:
    def __init__(self, name, type=None):
        self.name = name
        self.type = type

class VariableSymbol(Symbol):
    def __init__(self, name, type):
        super().__init__(name, type)

    def __str__(self):
        return f"<{self.name}:{self.type}>"

class SymbolTable:
    def __init__(self, parent=None):
        self.symbols = {}
        self.parent = parent

    def define(self, symbol):
        self.symbols[symbol.name] = symbol

    def lookup(self, name):
        symbol = self.symbols.get(name)
        if symbol is None and self.parent is not None:
            return self.parent.lookup(name)
        return symbol

class SemanticAnalyzer:
    """
    Traverses the AST to check for semantic errors.
    - Undeclared variables.
    - Type mismatches.
    - Redeclared variables in the same scope.
    """
    def __init__(self):
        self.errors = []

    def error(self, message, line):
        self.errors.append(f"Semantic Error: {message} on line {line}")

    def visit(self, node, scope):
        method_name = f'visit_{type(node).__name__}'
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node, scope)

    def generic_visit(self, node, scope):
        # Default behavior for nodes without a specific visitor method
        for field in node.__dict__.values():
            if isinstance(field, list):
                for item in field:
                    if isinstance(item, AST): self.visit(item, scope)
            elif isinstance(field, AST):
                self.visit(field, scope)
    
    def visit_Program(self, node, scope):
        global_scope = SymbolTable()
        for child in node.children:
            self.visit(child, global_scope)

    def visit_VarDecl(self, node, scope):
        var_name = node.var_node.value
        if scope.lookup(var_name):
            self.error(f"Variable '{var_name}' already declared in this scope", node.var_node.token.line)
            return

        var_type = node.type_node.value
        symbol = VariableSymbol(var_name, var_type)
        scope.define(symbol)

        if node.assign_node:
            right_type = self.visit(node.assign_node.right, scope)
            if var_type != right_type and not (var_type == 'float' and right_type == 'int'):
                self.error(f"Cannot assign type '{right_type}' to variable '{var_name}' of type '{var_type}'", node.var_node.token.line)

    def visit_Assign(self, node, scope):
        var_name = node.left.value
        symbol = scope.lookup(var_name)
        if not symbol:
            self.error(f"Variable '{var_name}' not declared", node.left.token.line)
            return 'error'

        right_type = self.visit(node.right, scope)
        if symbol.type != right_type and not (symbol.type == 'float' and right_type == 'int'):
            self.error(f"Cannot assign type '{right_type}' to variable '{var_name}' of type '{symbol.type}'", node.left.token.line)
        return symbol.type

    def visit_Variable(self, node, scope):
        var_name = node.value
        symbol = scope.lookup(var_name)
        if not symbol:
            self.error(f"Variable '{var_name}' not declared", node.token.line)
            return 'error'
        return symbol.type

    def visit_Number(self, node, scope):
        return 'float' if '.' in node.value else 'int'

    def visit_BinOp(self, node, scope):
        left_type = self.visit(node.left, scope)
        right_type = self.visit(node.right, scope)

        # Type promotion: if either operand is float, the result is float.
        if 'error' in (left_type, right_type): return 'error'
        if left_type == 'float' or right_type == 'float':
            return 'float'
        return 'int'

    def visit_If(self, node, scope):
        self.visit(node.condition, scope)
        self.visit(node.if_block, SymbolTable(parent=scope)) # New scope for 'if' block
        if node.else_block:
            self.visit(node.else_block, SymbolTable(parent=scope)) # New scope for 'else' block
            
    def visit_Block(self, node, scope):
        block_scope = SymbolTable(parent=scope) # Each block gets a new scope
        for statement in node.statements:
            self.visit(statement, block_scope)

    def analyze(self, ast):
        self.visit(ast, scope=None)
        return self.errors
