class CodeGenerator:
    """
    Generates final target code (hypothetical x86 Assembly) from the IR.
    """
    def __init__(self, ir_code):
        self.ir_code = ir_code
        self.assembly_code = []
        # Find all variables to declare them in the data section
        self.vars = {
            item
            for _, arg1, arg2, result in ir_code
            for item in [arg1, arg2, result]
            if isinstance(item, str) and not item.replace('.', '', 1).isdigit() and not item.startswith(('t', 'L'))
        }

    def generate(self):
        self.assembly_code.append("section .data")
        for var in self.vars:
            self.assembly_code.append(f"    {var} DD 0.0") # Declare all as 32-bit floats for simplicity

        self.assembly_code.append("\nsection .text")
        self.assembly_code.append("global _start")
        self.assembly_code.append("_start:")
        
        op_map = {'ADD': 'addsd', 'SUB': 'subsd', 'MUL': 'mulsd', 'DIV': 'divsd'}
        cmp_map = {'GT': 'jg', 'LT': 'jl', 'EQ': 'je', 'NEQ': 'jne', 'GTE': 'jge', 'LTE': 'jle'}

        for op, arg1, arg2, result in self.ir_code:
            self.assembly_code.append(f"    ; {op}, {arg1}, {arg2}, {result}")
            if op == 'ASSIGN':
                if self.is_numeric(arg1):
                    self.assembly_code.append(f"    mov dword [__float32__({arg1})], eax")
                    self.assembly_code.append(f"    movd xmm0, eax")
                else: # variable
                    self.assembly_code.append(f"    movsd xmm0, [{arg1}]")
                self.assembly_code.append(f"    movsd [{result}], xmm0")
            elif op in op_map:
                self.assembly_code.append(f"    movsd xmm0, [{arg1}]")
                self.assembly_code.append(f"    movsd xmm1, [{arg2}]")
                self.assembly_code.append(f"    {op_map[op]} xmm0, xmm1")
                self.assembly_code.append(f"    movsd [{result}], xmm0")
            elif op in cmp_map:
                self.assembly_code.append(f"    movsd xmm0, [{arg1}]")
                self.assembly_code.append(f"    movsd xmm1, [{arg2}]")
                self.assembly_code.append(f"    comisd xmm0, xmm1")
                # We need a label to jump to, which is handled by IF_FALSE_GOTO
                # Store a boolean result (1 for true, 0 for false)
                true_label = f"L_{len(self.assembly_code)}"
                end_label = f"L_{len(self.assembly_code)+1}"
                self.assembly_code.append(f"    {cmp_map[op]} {true_label}")
                self.assembly_code.append(f"    mov dword [{result}], 0") # False
                self.assembly_code.append(f"    jmp {end_label}")
                self.assembly_code.append(f"{true_label}:")
                self.assembly_code.append(f"    mov dword [{result}], 1") # True
                self.assembly_code.append(f"{end_label}:")
            elif op == 'IF_FALSE_GOTO':
                self.assembly_code.append(f"    mov eax, [{arg1}]")
                self.assembly_code.append(f"    cmp eax, 0")
                self.assembly_code.append(f"    je {result}")
            elif op == 'GOTO':
                self.assembly_code.append(f"    jmp {result}")
            elif op == 'LABEL':
                self.assembly_code.append(f"{result}:")

        # Standard exit syscall for Linux x86
        self.assembly_code.append("\n    ; Exit program")
        self.assembly_code.append("    mov eax, 1")
        self.assembly_code.append("    xor ebx, ebx")
        self.assembly_code.append("    int 0x80")
        
        return "\n".join(self.assembly_code)
    
    def is_numeric(self, s):
        if s is None: return False
        try:
            float(s)
            return True
        except (ValueError, TypeError):
            return False
