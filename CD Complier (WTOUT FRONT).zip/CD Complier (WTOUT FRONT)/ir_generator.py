class IRGenerator:
    """
    Generates Three-Address Code (TAC) from the AST.
    """
    def __init__(self):
        self.temp_count = 0
        self.label_count = 0
        self.ir_code = []

    def new_temp(self):
        self.temp_count += 1
        return f"t{self.temp_count}"

    def new_label(self):
        self.label_count += 1
        return f"L{self.label_count}"

    def add_code(self, op, arg1=None, arg2=None, result=None):
        self.ir_code.append((op, arg1, arg2, result))

    def generate(self, node):
        self.visit(node)
        return self.ir_code

    def visit(self, node):
        method_name = f'visit_{type(node).__name__}'
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        # Default for nodes like Program, Block to visit children
        for field in node.__dict__.values():
            if isinstance(field, list):
                for item in field: self.visit(item)
            elif hasattr(field, '__class__') and 'AST' in str(field.__class__.__mro__):
                self.visit(field)

    def visit_VarDecl(self, node):
        if node.assign_node:
            self.visit(node.assign_node)

    def visit_Assign(self, node):
        var_name = node.left.value
        expr_val = self.visit(node.right)
        self.add_code('ASSIGN', expr_val, result=var_name)

    def visit_BinOp(self, node):
        left_val = self.visit(node.left)
        right_val = self.visit(node.right)
        op_map = {'+': 'ADD', '-': 'SUB', '*': 'MUL', '/': 'DIV',
                  '>': 'GT', '<': 'LT', '==': 'EQ', '!=': 'NEQ', '>=': 'GTE', '<=': 'LTE'}
        
        op = node.op.value
        result_temp = self.new_temp()
        self.add_code(op_map[op], left_val, right_val, result=result_temp)
        return result_temp

    def visit_Number(self, node):
        return node.value

    def visit_Variable(self, node):
        return node.value

    def visit_If(self, node):
        cond_val = self.visit(node.condition)
        
        else_label = self.new_label()
        end_label = self.new_label()

        # If condition is false (0), jump to the else part
        self.add_code('IF_FALSE_GOTO', cond_val, result=else_label)
        
        self.visit(node.if_block)
        # After 'if' block, jump to the end
        self.add_code('GOTO', result=end_label)

        self.add_code('LABEL', result=else_label)
        if node.else_block:
            self.visit(node.else_block)
        
        self.add_code('LABEL', result=end_label)
