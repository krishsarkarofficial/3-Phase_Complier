import sys
from lexer import tokenize
from parser import Parser
from semantic_analyzer import SemanticAnalyzer
from ir_generator import IRGenerator
from optimizer import Optimizer
from code_generator import CodeGenerator

def main():
    if len(sys.argv) != 3:
        print("Usage: python compiler.py <input_file> <output_file>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    try:
        with open(input_file, 'r') as f:
            source_code = f.read()
    except FileNotFoundError:
        print(f"Error: Input file '{input_file}' not found.")
        sys.exit(1)

    # --- 1. Lexical Analysis ---
    print("1. Starting Lexical Analysis...")
    tokens, lexer_errors = tokenize(source_code)
    if lexer_errors:
        print("\nLexical Errors Found:")
        for error in lexer_errors: print(error)
        sys.exit(1)
    print("   -> Lexer finished successfully.")

    # --- 2. Syntax Analysis (Parsing) ---
    print("\n2. Starting Syntax Analysis...")
    parser = Parser(tokens)
    ast, parser_errors = parser.parse()
    if parser_errors:
        print("\nSyntax Errors Found:")
        for error in parser_errors: print(error)
        sys.exit(1)
    print("   -> Parser finished successfully. AST generated.")

    # --- 3. Semantic Analysis ---
    print("\n3. Starting Semantic Analysis...")
    semantic_analyzer = SemanticAnalyzer()
    semantic_errors = semantic_analyzer.analyze(ast)
    if semantic_errors:
        print("\nSemantic Errors Found:")
        for error in semantic_errors: print(error)
        sys.exit(1)
    print("   -> Semantic analysis finished successfully.")

    # --- 4. Intermediate Code Generation ---
    print("\n4. Generating Intermediate Code (IR)...")
    ir_gen = IRGenerator()
    ir_code = ir_gen.generate(ast)
    print("   -> IR generated.")

    # --- 5. Optimization ---
    print("\n5. Optimizing IR...")
    optimizer = Optimizer(ir_code)
    optimized_ir = optimizer.optimize()
    print("   -> Optimization finished.")

    # --- 6. Final Code Generation ---
    print("\n6. Generating Final Assembly Code...")
    code_gen = CodeGenerator(optimized_ir)
    final_code = code_gen.generate()
    print("   -> Final code generated.")

    # --- 7. Write to Output File ---
    try:
        with open(output_file, 'w') as f:
            f.write(final_code)
        print(f"\nCompilation successful! Output written to '{output_file}'")
    except IOError:
        print(f"Error: Could not write to output file '{output_file}'.")
        sys.exit(1)

if __name__ == "__main__":
    main()
