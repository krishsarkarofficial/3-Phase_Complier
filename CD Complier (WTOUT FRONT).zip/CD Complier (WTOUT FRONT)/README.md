# Simple C-like Compiler

This project is an educational, multi-stage compiler for a small, C-like
programming language, built entirely in Python. It serves as a practical
demonstration of the classic phases of compilation, transforming
human-readable source code into hypothetical machine-level assembly
code.

It is an excellent tool for anyone looking to understand the inner
workings of compilers, from lexical analysis to final code generation.

------------------------------------------------------------------------

## 🧩 Language Features

The supported language is minimal but statically typed, providing a
solid foundation for understanding compiler theory.

-   **Data Types:** `int` and `float`\
-   **Variable Declarations:** With optional in-line initialization
    (e.g., `int x = 10;`)\
-   **Arithmetic Operators:** `+`, `-`, `*`, `/`\
-   **Relational Operators:** `>`, `<`, `==`, `!=`, `>=`, `<=`\
-   **Control Flow:** Standard `if-else` statements\
-   **Scoped Blocks:** Using curly braces `{}` to define local scopes\
-   **Comments:** Single-line comments starting with `//` are ignored by
    the lexer

------------------------------------------------------------------------

## 🏗️ Compiler Architecture

The compiler is broken down into a pipeline of distinct stages, each
implemented in its own Python module. This modular design makes the
process transparent and easier to follow.

  -----------------------------------------------------------------------
  Module                          Purpose
  ------------------------------- ---------------------------------------
  `lexer.py`                      **Lexical Analyzer**: Scans the source
                                  code and converts it into a stream of
                                  tokens (e.g., numbers, identifiers,
                                  operators).

  `parser.py`                     **Syntax Analyzer**: Builds an Abstract
                                  Syntax Tree (AST) representing the
                                  grammatical structure of the code.

  `semantic_analyzer.py`          **Semantic Analyzer**: Checks for
                                  semantic correctness using a Symbol
                                  Table.

  `ir_generator.py`               **Intermediate Code Generator**:
                                  Produces Three-Address Code (TAC).

  `optimizer.py`                  **Code Optimizer**: Performs constant
                                  folding and other simple optimizations.

  `code_generator.py`             **Final Code Generator**: Translates
                                  the optimized IR into simplified
                                  assembly code.

  `compiler.py`                   **Main Driver**: Orchestrates the
                                  entire pipeline.
  -----------------------------------------------------------------------

------------------------------------------------------------------------

## ⚙️ How to Run the Compiler

### Prerequisites

-   Python 3.x

### Steps

1.  **Prepare the Environment:**\
    Ensure all the Python files (`compiler.py`, `lexer.py`, etc.) are
    located in the same directory.

2.  **Create a Source File:**\
    Write your code in a text file with any extension (e.g.,
    `test.src`).

    **Example `test.src`:**

    ``` c
    // A simple program to test the compiler
    int a = 20;
    int b = 10;
    float result;

    if (a > b) {
      result = a - b; // result should be 10
    } else {
      result = 0;
    }
    ```

3.  **Execute the Compiler:**\
    Open your terminal or command prompt, navigate to the project
    directory, and run the main driver script using the following
    format:

    ``` bash
    python compiler.py <input_file> <output_file>
    ```

    **Example Command:**

    ``` bash
    python compiler.py test.src output.asm
    ```

4.  **Review the Output:**\
    If successful, a new file named `output.asm` will be created
    containing the generated assembly code. The terminal will show the
    progress through each stage.

------------------------------------------------------------------------

## 🚨 Error Handling

The compiler is designed to catch errors at each stage and will exit
with a descriptive message.

-   **Lexical Errors:** Invalid characters (e.g., `@`, `!`).\
-   **Syntax Errors:** Grammatical mistakes (e.g., missing semicolons,
    mismatched parentheses).\
-   **Semantic Errors:** Logical issues (e.g., using undeclared
    variables, type mismatches).

------------------------------------------------------------------------

## 🚀 Future Improvements

This project has a solid foundation that can be extended with more
advanced features:

-   Additional Control Flow: Implementing `for` and `while` loops\
-   Expanded Type System: Adding support for `char` and `string` types\
-   Functions: Adding function definitions and calls\
-   More Optimizations: Techniques like dead code elimination or loop
    unrolling\
-   Advanced Code Generation: Targeting a real assembler like NASM or
    generating code for a different architecture

------------------------------------------------------------------------

**Author:** *Your Name*\
**License:** MIT License
